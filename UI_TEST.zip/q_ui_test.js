/* 각 문제는 function 내부만 작업하시오. */

$(document).ready(function(){
    fnCheckId();
    fnCheckPw();
    fnCheckName();
    fnCheckEmail();
    fnCheckSubmit();
});

// 1. 아이디
function fnCheckId(){
    
}

// 2. 비밀번호
function fnCheckPw(){
    
}
 
// 3. 이름
function fnCheckName(){
    
}

// 4. 이메일
function fnCheckEmail(){
    
}

// 5. 서브밋
function fnCheckSubmit(){
    
}